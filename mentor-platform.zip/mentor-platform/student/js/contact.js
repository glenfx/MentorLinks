document.getElementById('contactForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const btn = e.target.querySelector('button');
    const name = document.getElementById('contactName').value;
    
    // 1. Visual Feedback: Processing State
    btn.innerText = "Sending...";
    btn.disabled = true;
    btn.style.opacity = "0.7";

    // 2. Simulate Server Delay
    setTimeout(() => {
        // 3. Success Alert
        alert(`Thank you, ${name}! Your message has been sent to the MentorLinks team. We will get back to you within 24 hours.`);
        
        // 4. Reset UI
        btn.innerText = "Send Message";
        btn.disabled = false;
        btn.style.opacity = "1";
        e.target.reset();
    }, 1500);
});