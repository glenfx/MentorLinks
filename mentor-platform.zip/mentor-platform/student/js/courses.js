// Professional Fake Course Data
const courses = [
    {
        id: 1,
        title: "Advanced React Patterns",
        category: "Web Development",
        mentor: "John Doe",
        lessons: 24,
        duration: "10h 45m",
        icon: "⚛️",
        level: "Advanced"
    },
    {
        id: 2,
        title: "UI/UX Case Study Masterclass",
        category: "UI/UX Design",
        mentor: "Jane Smith",
        lessons: 18,
        duration: "8h 20m",
        icon: "🎨",
        level: "Intermediate"
    },
    {
        id: 3,
        title: "Ethical Hacking 101",
        category: "Cybersecurity",
        mentor: "Mark Wilson",
        lessons: 30,
        duration: "15h 00m",
        icon: "🛡️",
        level: "Beginner"
    },
    {
        id: 4,
        title: "Data Visualization with D3",
        category: "Data Science",
        mentor: "Alice Brown",
        lessons: 12,
        duration: "6h 30m",
        icon: "📊",
        level: "Intermediate"
    }
];

// Track enrolled courses in local memory for the session
let enrolledIds = [];

function renderCourses(filter = "All Courses") {
    const container = document.getElementById("courseContainer");
    container.innerHTML = "";

    const filtered = filter === "All Courses" 
        ? courses 
        : courses.filter(c => c.category === filter);

    filtered.forEach(course => {
        const isEnrolled = enrolledIds.includes(course.id);
        const card = document.createElement("div");
        card.className = "course-card";
        
        card.innerHTML = `
            <div class="course-image">${course.icon}</div>
            <span class="badge">${course.level}</span>
            <h3 style="margin: 10px 0 5px 0;">${course.title}</h3>
            <p style="font-size: 13px; color: #64748b; margin-bottom: 15px;">By ${course.mentor}</p>
            
            <div style="display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 20px; color: #4b5563;">
                <span>📚 ${course.lessons} Lessons</span>
                <span>⏱️ ${course.duration}</span>
            </div>

            <button onclick="handleEnroll(${course.id}, this)" class="enroll-btn ${isEnrolled ? 'active' : ''}">
                ${isEnrolled ? '✓ Enrolled' : 'Enroll Now'}
            </button>
        `;
        container.appendChild(card);
    });
}

function handleEnroll(id, btn) {
    if (enrolledIds.includes(id)) {
        alert("You are already enrolled in this course! Check your dashboard.");
        return;
    }

    // Professional feedback loop
    btn.innerText = "Processing...";
    btn.style.opacity = "0.7";

    setTimeout(() => {
        enrolledIds.push(id);
        btn.innerText = "✓ Enrolled";
        btn.classList.add("active");
        btn.style.opacity = "1";
        
        // Show a success toast/alert
        alert(`Successfully enrolled in ${courses.find(c => c.id === id).title}!`);
    }, 800);
}

// Filter Logic
document.querySelectorAll('.filter-tag').forEach(tag => {
    tag.addEventListener('click', () => {
        document.querySelector('.filter-tag.active').classList.remove('active');
        tag.classList.add('active');
        renderCourses(tag.innerText);
    });
});

// Initial Load
window.onload = () => renderCourses();