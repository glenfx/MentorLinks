const chatWindow = document.getElementById('chatWindow');
const userInput = document.getElementById('userInput');

function sendMessage() {
    const text = userInput.value.trim();
    if (text === "") return;

    // 1. Add User Message to UI
    appendMessage("You", text, true);
    userInput.value = "";

    // 2. Simulate "Live" feel with a delayed response
    setTimeout(() => {
        simulateResponse(text);
    }, 1500);
}

function appendMessage(sender, text, isMine = false) {
    const msgDiv = document.createElement('div');
    msgDiv.className = 'message';
    if (isMine) msgDiv.style.flexDirection = 'row-reverse';

    msgDiv.innerHTML = `
        <div class="avatar" style="${isMine ? 'color: var(--primary)' : 'color: #e11d48'}">
            ${sender.charAt(0).toUpperCase()}
        </div>
        <div class="msg-content ${isMine ? 'mine' : ''}">
            <strong>${sender}</strong><br>
            ${text}
        </div>
    `;

    chatWindow.appendChild(msgDiv);
    chatWindow.scrollTop = chatWindow.scrollHeight; // Auto-scroll to bottom
}

function simulateResponse(userText) {
    const responses = [
        "That's a great point! I was wondering the same thing.",
        "Welcome to the community! Feel free to ask anything.",
        "Check out the #web-dev-help channel for more details on that.",
        "I just finished that course, it's amazing!"
    ];
    
    // Choose a random response
    const randomReply = responses[Math.floor(Math.random() * responses.length)];
    appendMessage("Community Bot", randomReply, false);
}

// Allow "Enter" key to send message
userInput.addEventListener("keypress", (e) => {
    if (e.key === "Enter") sendMessage();
});
// --- EMOJI PICKER LOGIC ---
function toggleEmojiPicker() {
    document.getElementById('emojiPicker').classList.toggle('hidden');
}

function addEmoji(emoji) {
    const input = document.getElementById('userInput');
    input.value += emoji;
    document.getElementById('emojiPicker').classList.add('hidden');
    input.focus();
}

// --- FILE UPLOAD SIMULATION ---
function simulateFileUpload() {
    // Simulate a file selection dialog
    const fileName = prompt("Select a file to upload (Simulation):", "Project_Proposal.pdf");
    
    if (fileName) {
        const fileHtml = `
            <div class="file-bubble">
                <span style="font-size: 24px;">📄</span>
                <div>
                    <div style="font-weight: bold; font-size: 13px;">${fileName}</div>
                    <div style="font-size: 11px; color: #64748b;">PDF Document • 1.2 MB</div>
                </div>
            </div>
        `;
        appendMessage("You", fileHtml, true);
        
        // Bot reacts to the file
        setTimeout(() => {
            appendMessage("John Doe", "Thanks for sharing the proposal! I'll take a look at it now. 🚀", false);
        }, 2000);
    }
}

// --- UPDATED SEND MESSAGE ---
function sendMessage() {
    const text = userInput.value.trim();
    if (text === "") return;

    appendMessage("You", text, true);
    userInput.value = "";
    
    // Close emoji picker if open
    document.getElementById('emojiPicker').classList.add('hidden');

    setTimeout(() => {
        simulateResponse(text);
    }, 1500);
}

// Ensure the appendMessage function supports HTML for the file bubbles
function appendMessage(sender, text, isMine = false) {
    const msgDiv = document.createElement('div');
    msgDiv.className = 'message';
    if (isMine) msgDiv.style.flexDirection = 'row-reverse';

    msgDiv.innerHTML = `
        <div class="avatar" style="${isMine ? 'color: var(--primary)' : 'color: #e11d48'}">
            ${sender.charAt(0).toUpperCase()}
        </div>
        <div class="msg-content ${isMine ? 'mine' : ''}">
            <strong>${sender}</strong><br>
            ${text}
        </div>
    `;

    chatWindow.appendChild(msgDiv);
    chatWindow.scrollTop = chatWindow.scrollHeight;
}