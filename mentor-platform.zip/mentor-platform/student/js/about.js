// Simple counter animation for professional feel
function animateValue(obj, start, end, duration) {
    let startTimestamp = null;
    const step = (timestamp) => {
        if (!startTimestamp) startTimestamp = timestamp;
        const progress = Math.min((timestamp - startTimestamp) / duration, 1);
        obj.innerHTML = Math.floor(progress * (end - start) + start) + (end > 1000 ? "k+" : "+");
        if (progress < 1) {
            window.requestAnimationFrame(step);
        }
    };
    window.requestAnimationFrame(step);
}

// Trigger counters when page loads
window.onload = () => {
    const mentorCount = document.getElementById("count-mentors");
    const studentCount = document.getElementById("count-students");
    const courseCount = document.getElementById("count-courses");

    animateValue(mentorCount, 0, 500, 2000);
    animateValue(studentCount, 0, 10, 2000); // For 10k
    animateValue(courseCount, 0, 250, 2000);
};
// Add this to your student/js/about.js

const observerOptions = {
    threshold: 0.2
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = "1";
            entry.target.style.transform = "translateY(0)";
        }
    });
}, observerOptions);

document.querySelectorAll('.team-card').forEach(card => {
    card.style.opacity = "0";
    card.style.transform = "translateY(30px)";
    card.style.transition = "all 0.6s ease-out";
    observer.observe(card);
});