auth.onAuthStateChanged(async user => {
  if (!user) location.href = "/login.html";
});
