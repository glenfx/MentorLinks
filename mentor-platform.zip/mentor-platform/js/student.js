// ============================
// RATE MENTOR FUNCTION
// ============================
async function rateMentor(mentorId, value) {
  try {
    const mentorRef = db.collection("users").doc(mentorId);
    const doc = await mentorRef.get();

    const data = doc.data();

    const newRating =
      (data.rating * data.totalRatings + value) /
      (data.totalRatings + 1);

    await mentorRef.update({
      rating: newRating,
      totalRatings: firebase.firestore.FieldValue.increment(1)
    });

    alert("Rating submitted successfully");

  } catch (error) {
    alert(error.message);
  }
}


// ============================
// LOAD MENTORS (ONLY IF PAGE HAS mentorList)
// ============================
const list = document.getElementById("mentorList");

if (list) {
  db.collection("users")
    .where("role", "==", "mentor")
    .onSnapshot(snapshot => {

      list.innerHTML = "";

      snapshot.forEach(doc => {
        const m = doc.data();

        list.innerHTML += `
          <div class="card">
            <h3>${m.fullName}</h3>
            <p>${m.specialization || "General"}</p>
            <p>⭐ ${m.rating.toFixed(1)}</p>

            <div class="rating-buttons">
              <button onclick="rateMentor('${doc.id}', 1)">1</button>
              <button onclick="rateMentor('${doc.id}', 2)">2</button>
              <button onclick="rateMentor('${doc.id}', 3)">3</button>
              <button onclick="rateMentor('${doc.id}', 4)">4</button>
              <button onclick="rateMentor('${doc.id}', 5)">5</button>
            </div>
          </div>
        `;
      });
    });
}
