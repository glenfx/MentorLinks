// 1. FAKE DATA (Keep this at the top)
const mentors = [
    { id: 1, name: "John Doe", specialization: "Web Development", rating: 4.5 },
    { id: 2, name: "Jane Smith", specialization: "Cybersecurity", rating: 4.8 },
    { id: 3, name: "Alice Brown", specialization: "Data Science", rating: 4.2 },
    { id: 4, name: "Mark Wilson", specialization: "AI & ML", rating: 4.9 },
    { id: 5, name: "Emily Davis", specialization: "Networking", rating: 4.3 },
];

// 2. DOM ELEMENTS
const mentorList = document.getElementById("mentorList");
const searchInput = document.getElementById("searchMentor");

// 3. RENDER FUNCTION (The Professional Way)
function renderMentors(list) {
    if (!mentorList) return;
    
    mentorList.innerHTML = list.map(m => `
        <div class="mentor-card nm-card" style="background:#ecf0f3; padding:20px; border-radius:20px; box-shadow: 8px 8px 16px #d1d9e6; text-align:center; margin-bottom:15px;">
            <h3 style="margin-bottom:5px;">${m.name}</h3>
            <p style="color:#4B70E2; font-weight:bold; margin-bottom:5px;">${m.specialization}</p>
            <p>⭐ ${parseFloat(m.rating).toFixed(1)}</p>
            <div style="display:flex; gap:10px; margin-top:15px;">
                <button onclick="startChat('${m.name}')" 
                    style="flex:2; padding:10px; border-radius:10px; border:none; background:#4B70E2; color:white; font-weight:bold; cursor:pointer;">
                    Connect & Chat
                </button>
                <button onclick="rateMentor(${m.id})" 
                    style="flex:1; padding:10px; border-radius:10px; border:none; background:white; box-shadow: 3px 3px 6px #d1d9e6; cursor:pointer;">
                    Rate
                </button>
            </div>
        </div>
    `).join('');
}

// 4. NAVIGATION LOGIC
function startChat(mentorName) {
    localStorage.setItem('selectedMentor', mentorName);
    window.location.href = "chat.html";
}

// 5. RATING LOGIC
function rateMentor(id) {
    const mentor = mentors.find(m => m.id === id);
    const r = parseFloat(prompt(`Rate ${mentor.name} (1-5 stars):`));
    if (r >= 1 && r <= 5) {
        mentor.rating = ((parseFloat(mentor.rating) + r) / 2).toFixed(1);
        renderMentors(mentors);
    } else if (r) {
        alert("Invalid rating!");
    }
}

// 6. SEARCH LOGIC
if (searchInput) {
    searchInput.addEventListener("input", () => {
        const query = searchInput.value.toLowerCase();
        const filtered = mentors.filter(m =>
            m.name.toLowerCase().includes(query) ||
            m.specialization.toLowerCase().includes(query)
        );
        renderMentors(filtered);
    });
}

// 7. AUTH & PROFILE GREETING
auth.onAuthStateChanged(async (user) => {
    if (user) {
        try {
            const doc = await db.collection("users").doc(user.uid).get();
            if (doc.exists) {
                const userData = doc.data();
                const welcomeTitle = document.querySelector('.welcome h1');
                if (welcomeTitle) {
                    welcomeTitle.innerText = `Welcome, ${userData.fullName}!`;
                }
            }
        } catch (error) { console.log("Auth error:", error); }
    } else {
        window.location.href = "../index.html";
    }
});

// 8. LOGOUT
document.querySelector('#logoutBtn')?.addEventListener('click', (e) => {
    e.preventDefault();
    auth.signOut().then(() => { window.location.href = "../index.html"; });
});

// Initial Load
renderMentors(mentors);