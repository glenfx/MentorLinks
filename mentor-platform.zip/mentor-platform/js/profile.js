// Load current user data into inputs
auth.onAuthStateChanged(async (user) => {
    if (user) {
        const doc = await db.collection("users").doc(user.uid).get();
        if (doc.exists) {
            const data = doc.data();
            document.getElementById('profName').value = data.fullName || "";
            document.getElementById('profSpec').value = data.specialization || "";
            document.getElementById('profBio').value = data.bio || "";
        }
    } else {
        window.location.href = "../index.html";
    }
});

// Update Firestore when clicking Save
document.getElementById('saveProfile').addEventListener('click', async () => {
    const user = auth.currentUser;
    const btn = document.getElementById('saveProfile');
    
    const updatedData = {
        fullName: document.getElementById('profName').value,
        specialization: document.getElementById('profSpec').value,
        bio: document.getElementById('profBio').value
    };

    btn.innerText = "Saving...";
    btn.disabled = true;

    try {
        await db.collection("users").doc(user.uid).update(updatedData);
        alert("Profile updated successfully!");
    } catch (error) {
        alert("Error: " + error.message);
    } finally {
        btn.innerText = "Update Profile";
        btn.disabled = false;
    }
});