// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCgRfZCYjQN8nBnrLeTGRY47wx52NqXvf8",
  authDomain: "mentor-platform-1d6ff.firebaseapp.com",
  projectId: "mentor-platform-1d6ff",
  storageBucket: "mentor-platform-1d6ff.appspot.com",
  messagingSenderId: "452348800010",
  appId: "1:452348800010:web:e788242a94b1e5b8a0c3f3"
};

// Initialize Firebase (COMPAT STYLE)
firebase.initializeApp(firebaseConfig);

// Make these globally available
window.auth = firebase.auth();
window.db = firebase.firestore();
