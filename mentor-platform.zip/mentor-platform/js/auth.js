// ============================
// REGISTRATION HANDLER
// ============================
document.getElementById("registerForm")?.addEventListener("submit", async (e) => {
    e.preventDefault();
    console.log("Registration started...");

    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const role = document.getElementById("role").value;

    try {
        // Step 1: Create Auth User
        const cred = await auth.createUserWithEmailAndPassword(email, password);
        console.log("Auth User Created. UID:", cred.user.uid);

        // Step 2: Create Firestore Document
        await db.collection("users").doc(cred.user.uid).set({
            fullName: name,
            email: email,
            role: role,
            rating: 0,
            totalRatings: 0,
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        console.log("Firestore Document Created successfully!");

        // Step 3: Redirect
        if (role === "student") {
            window.location.href = "student/dashboard.html";
        } else {
            window.location.href = "mentor/dashboard.html";
        }

    } catch (error) {
        console.error("Registration Error Detail:", error);
        alert(error.message);
    }
});

// ============================
// LOGIN HANDLER
// ============================
document.getElementById("loginForm")?.addEventListener("submit", async (e) => {
    e.preventDefault();
    console.log("Login started...");

    const inputs = e.target.getElementsByTagName('input');
    const email = inputs[0].value;
    const password = inputs[1].value;

    try {
        const cred = await auth.signInWithEmailAndPassword(email, password);
        console.log("Login successful. Fetching profile for UID:", cred.user.uid);

        const doc = await db.collection("users").doc(cred.user.uid).get();

        if (doc.exists) {
            console.log("Profile found! Role:", doc.data().role);
            const role = doc.data().role;
            if (role === "student") {
                window.location.href = "student/dashboard.html";
            } else {
                window.location.href = "mentor/dashboard.html";
            }
        } else {
            console.error("Document does not exist in Firestore for this UID.");
            alert("No user profile found. Please delete this user in Auth and Register again.");
        }

    } catch (error) {
        console.error("Login Error Detail:", error);
        alert(error.message);
    }
});