// Live update sidebar name and initials
document.getElementById('mentorName').addEventListener('input', (e) => {
    const val = e.target.value;
    document.getElementById('sideName').innerText = val || "Mentor Name";
    if(val) {
        const initials = val.split(' ').map(n => n[0]).join('').toUpperCase();
        document.getElementById('avatarInitials').innerText = initials;
    }
});

document.getElementById('mentorExp').addEventListener('input', (e) => {
    document.getElementById('expDisplay').innerText = e.target.value;
});

// Load Data
auth.onAuthStateChanged(async (user) => {
    if (user) {
        const doc = await db.collection("users").doc(user.uid).get();
        if (doc.exists) {
            const data = doc.data();
            document.getElementById('mentorName').value = data.fullName || "";
            document.getElementById('mentorSpec').value = data.specialization || "";
            document.getElementById('mentorBio').value = data.bio || "";
            document.getElementById('mentorExp').value = data.experience || 5;
            
            // Set Side Display
            document.getElementById('sideName').innerText = data.fullName || "Mentor Name";
            document.getElementById('sideSpec').innerText = data.specialization || "Expert";
            document.getElementById('expDisplay').innerText = data.experience || 5;

            // Check the days
            const days = data.availability || [];
            document.querySelectorAll('.day-box input').forEach(box => {
                if(days.includes(box.value)) box.checked = true;
            });
        }
    }
});

// Save Data
document.getElementById('saveMentorProfile').onclick = async () => {
    const user = auth.currentUser;
    const checkedDays = Array.from(document.querySelectorAll('.day-box input:checked')).map(cb => cb.value);
    
    try {
        await db.collection("users").doc(user.uid).update({
            fullName: document.getElementById('mentorName').value,
            specialization: document.getElementById('mentorSpec').value,
            experience: document.getElementById('mentorExp').value,
            bio: document.getElementById('mentorBio').value,
            availability: checkedDays
        });
        alert("Profile Updated Successfully!");
    } catch (err) {
        alert("Error: " + err.message);
    }
};
