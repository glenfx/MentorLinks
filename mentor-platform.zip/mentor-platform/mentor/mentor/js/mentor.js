// Fake student data
const students = [
  { id: 1, name: "Alex Johnson", interest: "Web Development", email: "alex@mail.com", bio: "Beginner in web dev, looking for guidance." },
  { id: 2, name: "Maria Lee", interest: "Cybersecurity", email: "maria@mail.com", bio: "Interested in penetration testing and network security." },
  { id: 3, name: "Liam Brown", interest: "Data Science", email: "liam@mail.com", bio: "Passionate about AI and ML." },
  { id: 4, name: "Sophia Green", interest: "AI & ML", email: "sophia@mail.com", bio: "Building machine learning projects." },
  { id: 5, name: "Ethan White", interest: "Networking", email: "ethan@mail.com", bio: "Networking enthusiast and student." },
];

// Mentor info
let totalConnections = 0;
let mentorRating = 4.8;

// DOM elements
const studentList = document.getElementById("studentList");
const searchStudent = document.getElementById("searchStudent");
const totalConnectionsEl = document.getElementById("totalConnections");
const mentorRatingEl = document.getElementById("mentorRating");

// Modal elements
const modal = document.getElementById("studentModal");
const modalName = document.getElementById("modalName");
const modalInterest = document.getElementById("modalInterest");
const modalEmail = document.getElementById("modalEmail");
const modalBio = document.getElementById("modalBio");
const modalClose = document.querySelector(".close-btn");

// Render students
function renderStudents(list) {
  studentList.innerHTML = "";
  list.forEach(student => {
    const card = document.createElement("div");
    card.classList.add("student-card");
    
   card.innerHTML = `
  <h3>${student.name}</h3>
  <p>Interest: ${student.interest}</p>
  <div class="button-group">
    <button class="approve-btn">Approve Connection</button>
    <button class="message-btn">Message</button>
    <button class="profile-btn">View Profile</button>
  </div>
`;


    // Approve connection
    card.querySelector(".approve-btn").addEventListener("click", () => {
      totalConnections++;
      totalConnectionsEl.textContent = totalConnections;
      alert(`Connection approved with ${student.name}`);
    });

    // Message button
    card.querySelector(".message-btn").addEventListener("click", () => {
      alert(`Messaging ${student.name}... (placeholder)`);
    });

    // View Profile (modal)
    card.querySelector(".profile-btn").addEventListener("click", () => {
      modal.style.display = "block";
      modalName.textContent = student.name;
      modalInterest.textContent = `Interest: ${student.interest}`;
      modalEmail.textContent = `Email: ${student.email}`;
      modalBio.textContent = `Bio: ${student.bio}`;
    });

    studentList.appendChild(card);
  });
}

// Initial render
renderStudents(students);

// Search functionality
searchStudent.addEventListener("input", () => {
  const query = searchStudent.value.toLowerCase();
  const filtered = students.filter(s =>
    s.name.toLowerCase().includes(query) ||
    s.interest.toLowerCase().includes(query)
  );
  renderStudents(filtered);
});

// Close modal
modalClose.addEventListener("click", () => {
  modal.style.display = "none";
});

// Close modal when clicking outside content
window.addEventListener("click", (e) => {
  if (e.target === modal) modal.style.display = "none";
});
