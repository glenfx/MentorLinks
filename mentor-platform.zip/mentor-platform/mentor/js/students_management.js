// 1. ALL FAKE DATA (Combined)
const pendingRequests = [
    { id: 101, name: "Alex Johnson", interest: "Web Development", date: "2 hours ago" },
    { id: 102, name: "Maria Lee", interest: "Data Science", date: "5 hours ago" }
];

const activeMessages = [
    { 
        id: 201, 
        name: "Liam Brown", 
        course: "Advanced React", 
        progress: 85, 
        lastMsg: "I've finished the HTML module!", 
        time: "10:30 AM", 
        unread: 2 
    },
    { 
        id: 202, 
        name: "Sophia Green", 
        course: "UI/UX Masterclass", 
        progress: 40, 
        lastMsg: "Could we jump on a call tomorrow?", 
        time: "Yesterday", 
        unread: 0 
    }
];

// 2. TAB SWITCHING LOGIC
function switchTab(tab, event) {
    // Remove active class from all buttons
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    
    // Add active class to clicked button
    event.currentTarget.classList.add('active');

    if (tab === 'requests') {
        document.getElementById('requests-section').classList.remove('hidden');
        document.getElementById('messages-section').classList.add('hidden');
    } else {
        document.getElementById('requests-section').classList.add('hidden');
        document.getElementById('messages-section').classList.remove('hidden');
    }
}

// 3. RENDER REQUESTS
function renderRequests() {
    const list = document.getElementById('requestList');
    if(!list) return;
    list.innerHTML = pendingRequests.map(req => `
        <div class="request-card">
            <div class="student-meta">
                <h4>${req.name}</h4>
                <p>Wants to learn: <strong>${req.interest}</strong> • ${req.date}</p>
            </div>
            <div class="action-btns">
                <button class="btn-accept" onclick="acceptStudent(${req.id}, '${req.name}')">Accept</button>
                <button class="btn-decline" onclick="removeRequest(${req.id})">Decline</button>
            </div>
        </div>
    `).join('');
}

// 4. RENDER MESSAGES & PROGRESS
function renderMessages() {
    const list = document.getElementById('messageList');
    if(!list) return;
    list.innerHTML = activeMessages.map(msg => `
        <div class="message-item">
            <div class="student-meta" style="flex: 1;">
                <h4>${msg.name} ${msg.unread > 0 ? `<span class="unread-badge">${msg.unread} New</span>` : ''}</h4>
                <p style="margin-bottom: 10px;">Course: <strong>${msg.course}</strong></p>
                
                <div style="width: 80%; background: #d1d9e6; height: 8px; border-radius: 10px; box-shadow: inset 2px 2px 4px #b8c1cc;">
                    <div style="width: ${msg.progress}%; background: #4B70E2; height: 100%; border-radius: 10px;"></div>
                </div>
                <span style="font-size: 11px; color: #4B70E2; font-weight: bold;">${msg.progress}% Completed</span>
                <p style="margin-top:10px; font-size:12px; color:#64748b;">Last: ${msg.lastMsg}</p>
            </div>

            <div class="action-btns" style="text-align: right;">
                <span style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 10px;">${msg.time}</span>
                <button class="btn-chat" onclick="openStudentChat('${msg.name}')">Chat Now</button>
            </div>
        </div>
    `).join('');
}

// 5. ACTION FUNCTIONS
function acceptStudent(id, name) {
    alert(`${name} has been added to your students!`);
}

function removeRequest(id) {
    alert("Request declined.");
}

function openStudentChat(name) {
    localStorage.setItem('selectedStudent', name);
    // Note: ensure this path is correct based on where your file is
    window.location.href = "mentor_chat.html"; 
}

// 6. INITIAL LOAD
window.onload = () => {
    renderRequests();
    renderMessages();
};